package com.gac.aopsmaintenance.controller;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.gac.aopsmaintenance.datalayer.CorridorConnector;
import com.gac.aopsmaintenance.model.PageAuthorization;


@Controller
@Scope("session")
@SessionAttributes({"cn"})
public class HomeController
{
	@Autowired
	CorridorConnector cc;

	@GetMapping("/")
	public String landingPage(Model model, HttpServletRequest req)
	{
		model.addAttribute("auth", new PageAuthorization(req));
		return "home";
	}

	@GetMapping("/contact")
	public String contactUs(Model model, HttpServletRequest req)
	{
		model.addAttribute("auth", new PageAuthorization(req));
		return "contact";
	}

	@GetMapping("/userlogout")
	public String logOut(HttpServletRequest req) throws ServletException
	{
		req.logout();

		return "logout";
	}
}
