package com.gac.aopsmaintenance.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gac.aopsmaintenance.datalayer.ADConnector;
import com.gac.aopsmaintenance.datalayer.CorridorConnector;
import com.gac.aopsmaintenance.model.PageAuthorization;


@Controller
public class CorridorController 
{
	@Autowired
	CorridorConnector corrCon;
	
	@Autowired
	ADConnector adCon;

	@GetMapping("/corridor")
	public String corridorPage(Model model,
			@RequestParam(required = false) String page,
			@RequestParam(required = false) String numItems,
			@RequestParam(required = false) String loc,
			HttpServletRequest req
			)
	{
		List<String> errors = new ArrayList<String>(); // cumulative errors

		// 1. Parse and sanity check page number
		int pageInt = 1;
		if (page != null) try
		{
			pageInt = Integer.parseInt(page);
		}
		catch (NumberFormatException nfe)
		{
			errors.add("Invalid page '" + page + "'. Defaulting to " + pageInt + ".");
		}
		if (pageInt < 1)
		{
			pageInt = 1;
			errors.add("Invalid page '" + page + "'. Defaulting to " + pageInt + ".");
		}
		model.addAttribute("page", pageInt);
		
		// 2. Parse and sanity check page size
		int numItemsInt = 20;
		if (numItems != null) try
		{
			numItemsInt = Integer.parseInt(numItems);
		}
		catch (NumberFormatException nfe)
		{
			errors.add("Invalid number of items '" + numItems + "'. Defaulting to " + numItemsInt + ".");
		}
		if (numItemsInt < 1)
		{
			numItemsInt = 20;
			errors.add("Invalid number of items '" + numItems + "'. Defaulting to " + numItemsInt + ".");
		}
		model.addAttribute("numItems", numItemsInt);
		
		// 3. Figure out starting element from page number and size
		int start = numItemsInt * (pageInt - 1);
		model.addAttribute("counter", start);
		
		// 4. Get data based on permission and options
		if (req.isUserInRole("ROLE_AOPS_APP_ADMINS"))
		{
			// 4.1. If we're an admin and we specify a location other than ALL, filter the data
			if (loc == null || loc.equals("ALL"))
			{
				model.addAttribute("buyers", corrCon.getBuyers(start, numItemsInt));
			}
			else
			{
				if (!adCon.isValidSchema(loc))
				{
					errors.add("Invalid schema prefix '" + loc + "'. Defaulting to SAV.");
					loc = "SAV";
				}
				model.addAttribute("buyers", corrCon.getBuyers(loc, start, numItemsInt));
				model.addAttribute("loc", loc); // for the JSP to maintain the correct selection
			}
		}
		else
		{
			// mailstop abbrev. -> corridor abbrev., e.g. STL -> MSP or WES -> BAF
			String tloc = adCon.getSchemaForUser(req.getUserPrincipal().getName());
			if (tloc == null)
			{
				errors.add("Your location (" + loc + ") is invalid for this application or not recognized. Visit the 'Contact us' page if you believe this is in error.");
			}
			model.addAttribute("forcedLoc", tloc);
			model.addAttribute("buyers", corrCon.getBuyers(tloc, start, numItemsInt));
		}
		
		// 5. Unconditional attributes
		model.addAttribute("locNames", LocNames.self); // nice-looking location names
		model.addAttribute("errors", errors);
		model.addAttribute("auth", new PageAuthorization(req));
		return "corridor";
	}
	
	static public class LocNames 
	{
		private String
			SAV = "Savannah, GA",
			PBI = "West Palm Beach, FL",
			LGB = "Long Beach, CA",
			LHM = "Lincoln, CA",
			MSP = "St. Louis, MO (Cahokia, IL)",
			ATW = "Appleton, WI",
			DAL = "Dallas, TX",
			BQK = "Brunswick, GA",
			LAS = "Las Vegas, NV",
			BAF = "Westfield, MA";

		public String getSAV()
		{
			return SAV;
		}

		public String getPBI()
		{
			return PBI;
		}

		public String getLGB()
		{
			return LGB;
		}

		public String getLHM()
		{
			return LHM;
		}

		public String getMSP()
		{
			return MSP;
		}

		public String getATW()
		{
			return ATW;
		}

		public String getDAL()
		{
			return DAL;
		}

		public String getBQK()
		{
			return BQK;
		}

		public String getLAS()
		{
			return LAS;
		}

		public String getBAF()
		{
			return BAF;
		}
		
		static public LocNames self = new LocNames();
	}
}
