package com.gac.aopsmaintenance.datalayer;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.SearchScope;

import static org.springframework.ldap.query.LdapQueryBuilder.query;
import org.springframework.stereotype.Component;


@Component
public class ADConnector
{
	private LdapTemplate ldap;
	private Map<String, String> schemae;
	public Map<String, String> cachedInfo;
	private LocalDateTime cacheLastUpdated;
	
	/*@Autowired
	public void setLdapTemplate(LdapContextSource source)
	{
		ldap = new LdapTemplate(source);
	}*/

	public ADConnector()
	{
		LdapContextSource ldapInfo = new LdapContextSource();
		ldapInfo.setUrl("ldap://ldap-webapps.gac.gulfaero.com:389/");
		ldapInfo.setUserDn("cn=GTS-Script-WPS, ou=eGAC, o=GAC");
		ldapInfo.setPassword("Secure-12");
		ldapInfo.afterPropertiesSet();
		ldap = new LdapTemplate(ldapInfo);

		schemae = new HashMap<String, String>();
		schemae.put("SAV", "SAV");
		schemae.put("PAL", "PBI");
		schemae.put("LB-", "LGB");
		schemae.put("LIN", "LHM");
		schemae.put("STL", "MSP");
		schemae.put("APP", "ATW");
		schemae.put("DAL", "DAL");
		schemae.put("BRU", "BQK");
		schemae.put("LV-", "LAS");
		schemae.put("WES", "BAF");
	}

	private void doCacheCheck()
	{
		if (cacheLastUpdated == null 
				|| LocalDateTime.now().isAfter(cacheLastUpdated.plusHours(6)))
		{
			cacheLastUpdated = LocalDateTime.now();
			
			Map<String, String> cache = new HashMap<String, String>();
			LdapQuery query = query() // from a static import
					.base("o=gac")
					.searchScope(SearchScope.SUBTREE)
					.attributes("uid", "mailstop")
					.where("mailstop").isPresent()
					.and("uid").isPresent();
			ldap.search(query, new AttributesMapper<Object>() {
						@Override
						public Object mapFromAttributes(Attributes attributes) throws NamingException
						{
							String corr = schemae.get(
									attributes.get("mailstop").get().toString().substring(1, 4)
							);
							if (corr != null)
							{
								cache.put(attributes.get("uid").get().toString(), corr);								
							}
							
							return null;
						}
				
					});
			cachedInfo = cache;
		}
	}

	public String getSchemaForUser(String username)
	{
		doCacheCheck();
		
		return cachedInfo.get(username);
	}
	
	public boolean isValidSchema(String schema)
	{
		return schemae.containsValue(schema);
	}
}
