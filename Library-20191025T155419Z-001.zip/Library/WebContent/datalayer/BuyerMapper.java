package com.gac.aopsmaintenance.datalayer;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.gac.aopsmaintenance.model.Buyer;


public class BuyerMapper implements RowMapper<Buyer>
{
	@Override
	public Buyer mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		Buyer b = new Buyer();

		//b.setDetails(rs.getString("BUYER_DETAILS"));
		b.setLocation(sanitize(rs.getString("BUYER_SCHEMA").substring(0, 3)));
		b.setCode(rs.getLong("BUYER_CODE"));
		b.setUserID(sanitize(rs.getString("BUYER_USERID")));
		b.setName(sanitize(rs.getString("BUYER_NAME")));
		b.setEmail(sanitize(rs.getString("BUYER_EMAIL")));
		b.setFax(sanitize(rs.getString("BUYER_FAX")));
		b.setPhone(sanitize(rs.getString("BUYER_PHONE")));
		b.setDept(sanitize(rs.getString("BUYER_DEPT")));

		return b;
	}
	
	// Maybe move this out to a Utils class eventually
	private String sanitize(String in)
	{
		if (in == null) return null;
		return in
				.replaceAll("&", "&amp;")
				.replaceAll("<", "&lt;")
				.replaceAll(">", "&gt;");
	}
}
