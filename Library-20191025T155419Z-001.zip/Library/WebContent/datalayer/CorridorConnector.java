package com.gac.aopsmaintenance.datalayer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.gac.aopsmaintenance.model.Buyer;


@Repository
public class CorridorConnector
{
	@Autowired
	@Qualifier("datasourceV8JdbcTemplate")
	private JdbcTemplate template;

	private BuyerMapper buyerMapper = new BuyerMapper();
	
	/*
	 * Caching functionality
	 * Set cacheNeedsRefresh to true for any update to the database.
	 */
	private boolean cacheNeedsRefresh = true;
	private List<Buyer> cachedBuyers;
	private void doCacheCheck()
	{
		if (cacheNeedsRefresh)
		{
			cacheNeedsRefresh = false;
			cachedBuyers = template.query("select "
					+ "BUYER_DETAILS, BUYER_SCHEMA, BUYER_CODE, BUYER_USERID, BUYER_NAME, BUYER_EMAIL, BUYER_FAX, BUYER_PHONE, BUYER_DEPT "
					+ "from CSC_BUYER_DATA ", buyerMapper);
		}
	}

	public List<String> getColumns()
	{
		SqlRowSet res = template.queryForRowSet(
				"select COLUMN_NAME, DATA_TYPE from ALL_TAB_COLUMNS where TABLE_NAME = 'CSC_BUYER_DATA'");
		List<String> results = new ArrayList<String>();
		while (res.next())
		{
			results.add(res.getString("COLUMN_NAME") + ", " + res.getString("DATA_TYPE"));
		}
		return results;
	}

	public List<Buyer> getBuyers(int start, int items)
	{
		doCacheCheck();
		
		return Collections.unmodifiableList(
				cachedBuyers.stream()
				.skip(start)
				.limit(items)
				.collect(Collectors.toList()));
	}

	public List<Buyer> getBuyers(String loc, int start, int items)
	{
		doCacheCheck();
		
		return Collections.unmodifiableList(
				cachedBuyers.stream()
				.filter((Buyer b) -> { return b.getLocation().equals(loc); })
				.skip(start)
				.limit(items)
				.collect(Collectors.toList()));
	}
}
