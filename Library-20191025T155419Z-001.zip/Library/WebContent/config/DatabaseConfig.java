package com.gac.aopsmaintenance.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

@Configuration
public class DatabaseConfig {
	
	@Value("${spring.datasource.v8.jndi-name}")
	private String dataSourceV8JndiName;
	
	@Value("${spring.datasource.asr.jndi-name}")
	private String dataSourceASRJndiName;
	
	/*
	 * Probably not going to be used
	 * @Value("${spring.datasource.shr.jndi-name}")
	 * private String dataSourceShrJndiName;
	 */

	@Bean(name = "datasource-V8")
	public DataSource datasourceV8() {
		return (new JndiDataSourceLookup()).getDataSource(dataSourceV8JndiName);
	}

	@Bean(name = "datasourceV8JdbcTemplate")
	public JdbcTemplate datasourceV8JdbcTemplate(@Qualifier("datasource-V8") DataSource datasourceV8) {
		return new JdbcTemplate(datasourceV8);
	}
	
	@Bean(name = "datasource-ASR")
	public DataSource datasourceASR()
	{
		return (new JndiDataSourceLookup()).getDataSource(dataSourceASRJndiName);
	}
	
	@Bean(name = "datasourceASRJdbcTemplate")
	public JdbcTemplate datasourceASRJdbcTemplate(@Qualifier("datasource-ASR") DataSource datasourceASR)
	{
		return new JdbcTemplate(datasourceASR);
	}

	/*
	 * @Bean(name = "datasource-shr")
	 * public DataSource datasourceSHR() {
	 * 	return (new JndiDataSourceLookup()).getDataSource(dataSourceShrJndiName);
	 * }
	 *
	 * @Bean(name = "datasourceShrJdbcTemplate")
	 * public JdbcTemplate datasourceShrJdbcTemplate(@Qualifier("datasource-shr") DataSource datasourceShr) {
	 * 	return new JdbcTemplate(datasourceShr);
	 * }
	 */
	

}
