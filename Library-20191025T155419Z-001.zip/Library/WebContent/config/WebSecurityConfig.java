package com.gac.aopsmaintenance.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.LdapShaPasswordEncoder;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter
{

	private final String 
			role_admin = "ROLE_AOPS_APP_ADMINS",
			role_asr = "ROLE_AOPS_APP_ASR",
			role_corridor = "ROLE_AOPS_APP_CORRIDOR";

	// This is used for LDAP Config
	@Override
	protected void configure(HttpSecurity http) throws Exception
	{
		http.authorizeRequests()
				.antMatchers("/corridor/**").hasAnyAuthority(role_corridor, role_admin)
				.antMatchers("/asr/**").hasAnyAuthority(role_asr, role_admin)
				.antMatchers("/**").hasAnyAuthority(role_asr, role_corridor, role_admin)
				.anyRequest().fullyAuthenticated()
				.and().formLogin();
	}

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception
	{
		auth.ldapAuthentication()
				.userDnPatterns("cn={0},ou=USERS")
				.userSearchBase("o=gac")
				.userSearchFilter("cn={0}")
				.groupSearchBase("ou=GROUPS,ou=PORTAL,ou=eGAC,o=GAC")
				.groupSearchFilter("uniqueMember={0}")
				.contextSource(contextSource());
	}

	@Bean
	public LdapContextSource contextSource()
	{
		LdapContextSource contextSource = new LdapContextSource();
		contextSource.setUrl("ldap://ldap-webapps.gac.gulfaero.com:389/");
		// contextSource.setBase("o=gac");
		contextSource.setUserDn("cn=GTS-Script-WPS, ou=eGAC, o=GAC");
		contextSource.setPassword("Secure-12");
		return contextSource;
	}

	// Testing -- no security
	/*
	 * @Override protected void configure(HttpSecurity httpSecurity) throws
	 * Exception { //disabling headers so glyphicons will properly load
	 * httpSecurity.headers().cacheControl().disable();
	 * 
	 * httpSecurity.authorizeRequests().anyRequest().permitAll() .and()
	 * .csrf().disable()
	 * .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
	 * ;
	 * 
	 * }
	 */

	/*
	 * Authenticate Users with basic http and JDBC
	 */
	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.authorizeRequests().anyRequest().hasAnyRole("ADMIN", "USER", "TEST")
	 * .and().formLogin();
	 * 
	 * }
	 * 
	 * @Override protected void configure(AuthenticationManagerBuilder auth) throws
	 * Exception { auth.jdbcAuthentication().dataSource(dataSource).
	 * usersByUsernameQuery("select username, '$2a$10$hbxecwitQQ.dDT4JOFzQAulNySFwEpaFLw38jda6Td.Y/cOiRzDFu', 'TRUE' from shradmin.gac_aops_roles_assign where"
	 * + " username=?").
	 * authoritiesByUsernameQuery("select b.username, a.role_name from shradmin.gac_aops_roles a, shradmin.gac_aops_roles_assign b "
	 * + "where a.role_id = b.role_id" + " and b.username=?").passwordEncoder(new
	 * BCryptPasswordEncoder()); }
	 */

}
