var modal = document.getElementById("modal");
var btn = document.getElementById("test-modal");
var span = document.getElementById("exit");

btn.onclick = function() {
	modal.style.display = "block";
}

span.onclick = function() {
	modal.style.display = "none";
}