package com.gac.aopsmaintenance.model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class PageAuthorization
{
	private boolean asr;
	private boolean corridor;
	private boolean admin;

	public boolean getAsr()
	{
		return asr;
	}

	public boolean getCorridor()
	{
		return corridor;
	}
	
	public boolean getAdmin()
	{
		return admin;
	}

	public PageAuthorization(HttpServletRequest req)
	{
		if (req.isUserInRole("ROLE_AOPS_APP_ADMINS"))
		{
			admin = true;
			asr = true;
			corridor = true;
			return;
		}
		if (req.isUserInRole("ROLE_AOPS_APP_ASR"))
		{
			asr = true;
		}
		if (req.isUserInRole("ROLE_AOPS_APP_CORRIDOR"))
		{
			corridor = true;
		}
	}
	
	public PageAuthorization(boolean asr, boolean corridor, boolean admin)
	{
		this.asr = asr;
		this.corridor = corridor;
		this.admin = admin;
	}
}
